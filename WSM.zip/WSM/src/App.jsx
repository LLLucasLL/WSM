import { useState } from 'react'
import reactLogo from './assets/logo versao2_branca.png'
import viteLogo from '/vite.svg'
import './login.css'
import { Link } from "react-router-dom";

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <div className="login-page">
<div className="login-card-container">
        <div className="login-card">
            <div className="login-card-top">
              <div className="login-card-logo">
                  <img src={reactLogo} alt="logo" />
              </div>
                <div className="login-card-subtitle">
                    Web System Management
                </div>
            </div>
            <div className="login-card-header">
                <h1>Bem-vindo</h1>
                <div>Faça login para acessar o sistema</div>
            </div>
            <form className="login-card-form" action="processa_login1.php" method="post">
                <div className="form-item">
                    <span className="form-item-icon material-symbols-rounded">description</span>
                    <input type="number" placeholder="Digite seu ID" name="cpf" id="cpf" autoFocus required/>
                </div>
                <div className="form-item">
                    <span className="form-item-icon material-symbols-rounded">lock</span>
                    <input type="password" placeholder="Digite sua Senha" name="senha" id="senha" required/>
                </div>
                <div className="form-item-other">
                    <div className="checkbox">
                        <input type="checkbox" id="rememberMeCheckbox" defaultChecked/>
                        <label htmlFor="rememberMeCheckbox">Lembre-me</label>
                    </div>
                    <a href="#">Esqueci minha senha!</a>
                </div>
                <input className="button" type="submit" value="Login"/>
            </form>
            <div className="login-card-footer">
                Não tem uma conta? <a href="cadastro.html">Solicitar acesso.</a>
                    <Link to="/App">Login</Link>
                    <Link to="/P_create">Cadastro de Produto</Link>
            </div>
        </div>
    </div>
    </div>
    </>
  )
}

export default App
