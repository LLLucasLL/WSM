import { useState } from 'react';
import reactLogo from './assets/logo_principal_branca.png'
import './dashboard.css';
import { Link } from 'react-router-dom';

function PCreate() {
  
  // Criamos o estado inicial em uma constante
  const initialState = {
    nome: '',
    quantidade: '',
    valor: '',
    categoria: '',
    descricao: '',
    foto: null,
  };

  const [formData, setFormData] = useState(initialState);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const handleClear = () => {
    setFormData(initialState);
  };

  const validaForm = (e) => {
    e.preventDefault();
    const { nome, foto } = formData;

    if (!nome) {
      alert('Falta preencher o nome');
      return;
    }

    if (foto) {
      const extensoesValidas = ['jpg', 'jpeg', 'png'];
      const extensao = foto.name.split('.').pop().toLowerCase();

      if (!extensoesValidas.includes(extensao)) {
        alert('A imagem não é jpg, jpeg ou png');
        return;
      }
    }

    alert('Cadastro concluído');
    // Aqui você pode enviar os dados para o backend futuramente
  };

  return (
    <>
      <div className="sidebar">
        <ul className="side-menu">
          <li className="active"><Link to="/P_create"><i className="bx bxs-dog"></i>Create</Link></li>
          <li><a href="#"><i className="bx bxs-user-detail"></i>Update</a></li>
          <li><a href="#"><i className="bx bx-x-circle"></i>Delete</a></li>
          <li><a href="#"><i className="bx bx-receipt"></i>List</a></li>
          <li><a href="#"><i className="bx bxs-file-find"></i>Adoc./Apad.</a></li>
          <li><a href="#"><i className="bx bx-group"></i>Usuários</a></li>
        </ul>
        <ul className="side-menu">
          <li>
            <a href="#" className="logout">
              <i className="bx bx-log-out-circle"></i>
              Logout
            </a>
          </li>
        </ul>
      </div>

      <div className="content">
        <nav>
          <img src={reactLogo} alt="logo" />
          <i className="bx bx-menu"></i>
          <form>
            <div className="form-input">
              <input type="search" placeholder="Pesquisar..." />
              <button className="search-btn" type="submit"><i className="bx bx-search"></i></button>
            </div>
          </form>
          <input type="checkbox" id="theme-toggle" hidden />
          <label htmlFor="theme-toggle" className="theme-toggle"></label>
          <a href="#" className="notif">
            <i className="bx bx-bell"></i>
            <span className="count">12</span>
          </a>
        </nav>

        <main>
          <div className="bottom-data">
            <div className="orders">
              <div className="chartt">
                <div className="box-card-top">
                  <h2>Cadastro de Produto</h2>
                  <div className="box-card-subtitle">
                    Preencha os dados do novo produto
                  </div>
                </div>
                <div className="box">
                  <form onSubmit={validaForm}>
                    <label htmlFor="nome">Nome do Produto:</label>
                    <input type="text" id="nome" name="nome" required onChange={handleChange} /><br /><br />
                    
                    <div className="box-double">
                      <div className="field">
                        <label htmlFor="quantidade">Quantidade:</label>
                        <input type="text" id="quantidade" name="quantidade" required onChange={handleChange} />
                      </div>

                      <div className="field">
                        <label htmlFor="valor">Valor:</label>
                        <input type="text" id="valor" name="valor" required onChange={handleChange} />
                      </div>
                    </div>

                    <label htmlFor="categoria">Categoria:</label>
                    <select name="categoria" id="categoria" required onChange={handleChange}>
                      <option value="">Selecione uma categoria</option>
                      <option value="Femea">Fêmea</option>
                      <option value="Macho">Macho</option>
                    </select><br /><br />

                    <label htmlFor="descricao">Descrição:</label>
                    <textarea id="descricao" name="descricao" rows="4" required onChange={handleChange}></textarea><br /><br />


                      <div className="form-buttons">
                        <button
                          type="button"
                          className="btn-clear"
                          onClick={handleClear}
                        >
                          Limpar
                        </button>

                        <button
                          type="submit"
                          className="btn-submit"
                        >
                          Cadastrar Produto
                        </button>
                      </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
}

export default PCreate;
